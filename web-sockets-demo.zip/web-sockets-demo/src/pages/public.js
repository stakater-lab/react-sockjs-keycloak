import React, { Component } from 'react';

class Public extends Component {

  render() {
    return (
      <div>
        <p>This is your public-facing component.</p>
      </div>
    );
  }
}

export default Public;