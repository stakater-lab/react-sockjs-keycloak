import React, { Component } from 'react';
import Keycloak from 'keycloak-js';
import PropTypes from 'prop-types';

// import * as SockJS from './js/'

import LetterAvatarList from '../components/letterAvatarList';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Avatar from '@material-ui/core/Avatar';
import WorkIcon from '@material-ui/icons/Work';
import DeleteSweep from '@material-ui/icons/DeleteSweep';
import LinearProgress from '@material-ui/core/LinearProgress';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import IconButton from '@material-ui/core/IconButton';

import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  root: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
});

var stompClient = null;
var subscriptions = [];

class Private extends Component {
  
  constructor(props) {
    super(props);
    this.state = { keycloak: null, authenticated: false, user: null, userList: [] };
  }

  componentDidMount() {
    const keycloak = Keycloak('/keycloak.json');
    keycloak.init({onLoad: 'login-required', checkLoginIframe: false}).then(authenticated => {
      keycloak.loadUserInfo().then(userInfo => {
        this.setState({ keycloak: keycloak, authenticated: authenticated, user: userInfo });
        var socket = new window.SockJS('http://localhost:9002/ws');
        stompClient = window.Stomp.over(socket);
        stompClient.connect({ 'username': this.state.user.preferred_username, id: this.state.user.sub},  (frame) => {
          console.log('Connected: ' + frame);
        });
      });
    })
  }


  handleConnect = (channelId) => {
   var subscription = stompClient.subscribe('/topic/'+ channelId +'/connected.users',  (channels) => {
                        this.setState({userList: Object.assign(JSON.parse(channels.body))})
                      });
  
    this.subscribeChannel(channelId, this.state.user.sub);
    subscriptions.push(subscription);
  };

  subscribeChannel(channelId, userSubId) {
    stompClient.send("/app/channels/join",{}, channelId + ':' + userSubId);
  }

  handleLeave = (channelId) => {
    stompClient.send("/app/channels/leave",{}, channelId + ':' + this.state.user.sub);
  }

  unsubscribeChannel() {
    // TODO: handle unsubscribe event on individual channels
    this.subscriptions.map(subscription => subscription.unsubscribe());
  }

  handleDisconnect() {
    if (stompClient !== null) {
        stompClient.disconnect();
    }
  }

  render() {
    const { classes } = this.props;

    if (this.state.keycloak) {
      if (this.state.authenticated) {
        return (
          <div>
            <LetterAvatarList users={this.state.userList}/>
            <div className={classes.root}>
              <h1>Hello, {this.state.user.name}</h1>
              <List component="nav">
                <ListItem button>
                  <Avatar>
                    <WorkIcon />
                  </Avatar>
                  <ListItemText primary="Health Center 1" secondary="Ch-6c5b5a2a-add1" onClick={() => { this.handleConnect('Ch-6c5b5a2a-add1') }} />
                  <ListItemSecondaryAction onClick={() => { this.handleLeave('Ch-6c5b5a2a-add1') }}>
                    <IconButton aria-label="Leave">
                      <DeleteSweep />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
                <ListItem button>
                  <Avatar>
                    <WorkIcon />
                  </Avatar>
                  <ListItemText primary="Health Center 2" secondary="Ch-6c5b5a2a-add2" onClick={() => { this.handleConnect('Ch-6c5b5a2a-add2') }} />
                  <ListItemSecondaryAction onClick={() => { this.handleLeave('Ch-6c5b5a2a-add2') }}>
                    <IconButton aria-label="Leave">
                      <DeleteSweep />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              </List>
            </div>
          </div> );
      } else {
        return (<div>Unable to authenticate!</div>)
      }
    } else {
      return (
        <div>
          <LinearProgress />
        </div>
      );
    }
 
  }
}

Private.propTypes = {
  classes: PropTypes.object.isRequired,
};
export default withStyles(styles)(Private);